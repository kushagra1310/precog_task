import pandas as pd
import networkx as nx

def create_gephi_file(input_file='test.txt', output_file="graph_output.gexf"):
    # 1. Load Data
    # If no input file is provided, we create dummy data for demonstration
    if input_file is None:
        print("No input file provided. Generating sample data...")
        data = [
            ("Alice", "Colleague", "Bob"),
            ("Bob", "Manager", "Charlie"),
            ("Charlie", "Mentor", "Alice"),
            ("David", "Sibling", "Alice"),
            ("Eve", "Enemy", "Bob")
        ]
        # Create a DataFrame matching your "Node 1 | Relation | Node 2" format
        df = pd.DataFrame(data, columns=["Source", "Relation", "Target"])
    else:
        # Load your actual CSV file
        # Ensure your CSV has headers, or update 'names' accordingly
        print(f"Loading data from {input_file}...")
        df = pd.read_csv(input_file, sep=" ", engine='python', header=None)
        
        # NOTE: Update these column names to match your specific CSV headers
        # For example, if your CSV headers are 'Subject', 'Predicate', 'Object'
        df.rename(columns={
            df.columns[0]: "Source", 
            df.columns[1]: "Relation", 
            df.columns[2]: "Target"
        }, inplace=True)

    # 2. Initialize the Graph
    # Use DiGraph() for directed edges (arrows), Graph() for undirected
    G = nx.from_pandas_edgelist(
        df,
        source="Source",
        target="Target",
        edge_attr="Relation", # This saves the relation type as an attribute
        create_using=nx.DiGraph()
    )

    # 3. Rename Edge Attribute for Gephi Compatibility (Optional but Recommended)
    # Gephi automatically displays the 'label' attribute on edges. 
    # We copy the 'Relation' data to a 'label' attribute.
    for u, v, data in G.edges(data=True):
        if 'Relation' in data:
            data['label'] = data['Relation']

    # 4. Export to GEXF (Gephi's native XML format)
    try:
        nx.write_gexf(G, output_file)
        print(f"Success! Graph saved to '{output_file}'.")
        print(f"Nodes: {G.number_of_nodes()} | Edges: {G.number_of_edges()}")
    except Exception as e:
        print(f"Error saving file: {e}")

# Run the function
if __name__ == "__main__":
    # To use your own file, change None to your filename: e.g., create_gephi_file("my_data.csv")
    create_gephi_file('test.txt')